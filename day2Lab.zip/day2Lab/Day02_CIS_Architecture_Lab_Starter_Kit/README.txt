DAY 02 PARTICIPANT STARTER KIT

1. Read 01_case_brief.txt.
2. Open 03_Design_Package_Template.docx in Word and Save As a file with your initials.
3. Sign in to the approved AWS training account. In Amazon Bedrock open a suitable Chat/Text playground with an approved model.
4. Paste the FULL case brief once; then execute prompts A, B, C, D and E (02_copy_paste_prompts.txt) in the same chat.
5. After each prompt, copy the resulting table/summary into the matching section of the Word template.
6. Use 04_self_check.txt to verify your submission.

DO NOT CREATE OR MODIFY ANY AWS RESOURCES. NO REAL CLIENT DATA.

If Bedrock is unavailable, use the instructor-approved alternative AI chat environment and document the substitution.
The complete instructional steps are in Day02_Participant_Hands_On_Lab_Guide.docx (provided separately).
